#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Cola
{
    struct Persona* Primero;
    struct Persona* Ultimo;
};

struct Persona
{
    char Nombre[30];
    struct Persona* Next;
};


struct Cola* CrearCola()
{
    struct Cola* c = (struct Cola*)malloc(sizeof(struct Cola));
    c->Primero = c->Ultimo = NULL;
    return c;
}

struct Persona* CrearNodo( char* Nombre)
{
    struct Persona* n = (struct Persona*)malloc(sizeof( struct Persona ));
    strcpy( n->Nombre , Nombre );
    n->Next = NULL;
    return n;
}

/// Protipo

void Encolar( struct Cola* c , char* Nombre );
void Desencolar( struct Cola* c );
void Mostrar( struct Cola* C );


int main()
{
    struct Cola* c = CrearCola();

    Encolar( c , "Pedro" );
    Encolar( c , "Maria" );
    Encolar( c , "DEVLIN" );
    Encolar( c , "ronaldo" );

    Mostrar( c );

    Desencolar( c );

    Mostrar( c );

    return 0;
}

/// Implementacion

void Encolar( struct Cola* c , char* Nombre )
{
    struct Persona* newPersona = CrearNodo( Nombre );

    if ( c->Primero == NULL )
    {
        c->Primero = c->Ultimo = newPersona;
    }
    else
    {
        c->Ultimo->Next = newPersona;
        c->Ultimo = newPersona;
    }
}

void Desencolar( struct Cola* c )
{
    if( c->Primero == NULL )
    {
        printf("\n No hay nadie primero, no podemos desencolar \n");
        return;
    }

    struct Persona* PersonaEliminada = c->Primero;

    printf("\n  Desencolamos a %s \n", PersonaEliminada->Nombre );

    c->Primero = c->Primero->Next;

    if ( c->Primero == NULL )
    {
        c->Ultimo = NULL;
    }

    free(PersonaEliminada);
}

void Mostrar( struct Cola* C)
{
    struct Persona* actual = C->Primero;
    printf("\n------Mostramos la cola ----\n");

    while( actual )
    {
        printf("\n %s \n", actual->Nombre );
        actual = actual->Next;
    }

    printf("\n-----Fin Mostrar-----\n");
}



